<?php
// Email Configuration
// Update these settings according to your cPanel email configuration

// SMTP Configuration (recommended for cPanel)
define('EMAIL_USE_SMTP', false); // Set to true to use SMTP, false to use PHP mail()

// SMTP Settings (only used if EMAIL_USE_SMTP is true)
define('SMTP_HOST', 'maagroup@maagroup.in');  // Your cPanel mail server
define('SMTP_PORT', 587);                     // Usually 587 for TLS or 465 for SSL
define('SMTP_USERNAME', 'maagroup@maagroup.in'); // Your cPanel email
define('SMTP_PASSWORD', 'your_email_password');    // Your cPanel email password
define('SMTP_ENCRYPTION', 'tls');             // 'tls' or 'ssl'

// From Email Settings
define('FROM_EMAIL', 'noreply@yourdomain.com');  // Replace with your domain
define('FROM_NAME', 'Employee Management System');

// Email Function
function sendResetEmail($to, $subject, $message) {
    if (EMAIL_USE_SMTP) {
        // If you want to use SMTP (requires PHPMailer)
        // This is more reliable for cPanel hosting
        return sendSMTPEmail($to, $subject, $message);
    } else {
        // Use PHP's built-in mail() function
        $headers = "From: " . FROM_NAME . " <" . FROM_EMAIL . ">\r\n";
        $headers .= "Reply-To: " . FROM_EMAIL . "\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

        return mail($to, $subject, $message, $headers);
    }
}

function sendSMTPEmail($to, $subject, $message) {
    // Basic SMTP implementation - for production, consider using PHPMailer
    // This is a simple example

    $headers = "From: " . FROM_NAME . " <" . FROM_EMAIL . ">\r\n";
    $headers .= "Reply-To: " . FROM_EMAIL . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // For now, fallback to mail() function
    // In production, implement proper SMTP with PHPMailer
    return mail($to, $subject, $message, $headers);
}

// Test email function
function testEmailConfiguration() {
    $test_email = FROM_EMAIL;
    $subject = "Email Configuration Test";
    $message = "This is a test email to verify email configuration is working.";

    return sendResetEmail($test_email, $subject, $message);
}
?>