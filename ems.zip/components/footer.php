</div> <!-- End main-content -->
</div> <!-- End dashboard-container -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>