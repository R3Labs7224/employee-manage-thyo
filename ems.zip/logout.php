<?php
require_once 'includes/session.php';
logout();
?>